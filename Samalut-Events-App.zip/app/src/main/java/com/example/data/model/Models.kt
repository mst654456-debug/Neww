package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/** المراحل التعليمية المعتمدة */
enum class SchoolStage(val displayNameAr: String) {
    KINDERGARTEN("رياض أطفال"),
    PRIMARY("ابتدائي"),
    PREPARATORY("إعدادي"),
    GENERAL_SECONDARY("ثانوي عام"),
    TECHNICAL_SECONDARY("ثانوي فني"),
    COMMUNITY_EDUCATION("تعليم مجتمعي"),
    PRIVATE_SCHOOLS("مدارس خاصة")
}

fun stageLabel(stageName: String): String =
    SchoolStage.values().firstOrNull { it.name == stageName }?.displayNameAr ?: stageName

/** المدرسة: البيانات المأخوذة من استمارة بيانات المدرسة */
@Entity(tableName = "schools")
data class School(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val code: String = "",
    val serialNumber: String = "",
    val stage: String = SchoolStage.PRIMARY.name,
    val address: String = "",
    val principalName: String = "",
    val principalPhone: String = "",
    val vicePrincipalName: String = "",
    val vicePrincipalPhone: String = "",
    val securityOfficerName: String = "",
    val securityOfficerPhone: String = "",
    val crisisOfficerName: String = "",
    val crisisOfficerPhone: String = "",
    val safetyOfficerName: String = "",
    val safetyOfficerPhone: String = "",
    val teachersCount: Int = 0,
    val specialistsCount: Int = 0,
    val administrativeCount: Int = 0,
    val workersCount: Int = 0,
    val classroomsCount: Int = 0,
    val capacity: Int = 0,
    val studentsTotal: Int = 0,
    val boysCount: Int = 0,
    val girlsCount: Int = 0,
    val toiletsCount: Int = 0,
    val buildingsCount: Int = 0,
    val totalArea: String = "",
    val extinguishers: Int = 0,
    val extinguishersOk: Int = 0,
    val hoses: Int = 0,
    val hosesOk: Int = 0,
    val waterPumps: Int = 0,
    val waterPumpsOk: Int = 0,
    val tanks: Int = 0,
    val tanksOk: Int = 0,
    val sandBuckets: Int = 0,
    val sandBucketsOk: Int = 0,
    val cameras: Int = 0,
    val camerasOk: Int = 0,
    val gates: Int = 0,
    val gatesOk: Int = 0,
    val latitude: String = "",
    val longitude: String = "",
    val problems: String = ""
)

/** المعلم مرتبط بالمدرسة عن طريق schoolId */
@Entity(tableName = "teachers")
data class Teacher(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val schoolId: Long,
    val name: String,
    val code: String = "",
    val nationalId: String = "",
    val phone: String = "",
    val address: String = "",
    val notes: String = ""
)

/** الحدث: محفوظ لكل مدرسة */
@Entity(tableName = "events")
data class SchoolEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val schoolId: Long,
    val schoolName: String,
    val title: String,
    val description: String,
    val dateString: String,
    val timeString: String,
    val timestamp: Long
)
