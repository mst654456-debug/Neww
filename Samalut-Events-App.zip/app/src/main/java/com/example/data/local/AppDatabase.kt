package com.example.data.local

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import com.example.data.model.School
import com.example.data.model.SchoolEvent
import com.example.data.model.Teacher
import kotlinx.coroutines.flow.Flow

@Dao
interface SchoolDao {
    @Query("SELECT * FROM schools ORDER BY name ASC")
    fun observeAll(): Flow<List<School>>

    @Insert
    suspend fun insert(item: School): Long

    @Update
    suspend fun update(item: School)

    @Delete
    suspend fun delete(item: School)
}

@Dao
interface TeacherDao {
    @Query("SELECT * FROM teachers ORDER BY name ASC")
    fun observeAll(): Flow<List<Teacher>>

    @Insert
    suspend fun insert(item: Teacher): Long

    @Update
    suspend fun update(item: Teacher)

    @Delete
    suspend fun delete(item: Teacher)

    @Query("DELETE FROM teachers WHERE schoolId = :schoolId")
    suspend fun deleteBySchool(schoolId: Long)
}

@Dao
interface EventDao {
    @Query("SELECT * FROM events ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<SchoolEvent>>

    @Insert
    suspend fun insert(item: SchoolEvent): Long

    @Update
    suspend fun update(item: SchoolEvent)

    @Delete
    suspend fun delete(item: SchoolEvent)
}

@Database(
    entities = [School::class, Teacher::class, SchoolEvent::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun schoolDao(): SchoolDao
    abstract fun teacherDao(): TeacherDao
    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "edara_ahdath.db"
                ).build().also { instance = it }
            }
        }
    }
}
