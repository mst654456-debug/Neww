package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.SchoolSpec
import com.example.data.model.SchoolStage
import com.example.data.model.toValues
import com.example.ui.components.AppTopBar
import com.example.ui.components.FormFields
import com.example.ui.components.SectionTitle

@Composable
fun SchoolFormScreen(
    existing: School?,
    onSave: (Long, Map<String, String>) -> Unit,
    onBack: () -> Unit
) {
    val values = remember {
        mutableStateMapOf<String, String>().apply {
            putAll(existing?.toValues() ?: mapOf("stage" to SchoolStage.PRIMARY.name))
        }
    }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = if (existing == null) "إضافة مدرسة" else "تعديل بيانات المدرسة",
                onBack = onBack
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            SectionTitle("البيانات الأساسية")
            FormFields(SchoolSpec.basic, values)

            SectionTitle("المرحلة التعليمية")
            StageChooser(
                selected = values["stage"] ?: SchoolStage.PRIMARY.name,
                onSelect = { values["stage"] = it }
            )

            SectionTitle("القيادات والتواصل")
            FormFields(SchoolSpec.leadership, values)

            SectionTitle("الإحصاءات والقوى العاملة والطلاب")
            FormFields(SchoolSpec.stats, values)

            SectionTitle("منظومة الأمن والسلامة (الإجمالي / الصالح للعمل)")
            FormFields(SchoolSpec.safety, values)

            SectionTitle("الموقع الجغرافي")
            FormFields(SchoolSpec.location, values)

            SectionTitle("المشكلات داخل المدرسة")
            FormFields(SchoolSpec.problems, values)

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = {
                    if (values["name"].isNullOrBlank()) {
                        error = "اكتب اسم المدرسة أولاً"
                        return@Button
                    }
                    onSave(existing?.id ?: 0L, values.toMap())
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("حفظ بيانات المدرسة", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StageChooser(selected: String, onSelect: (String) -> Unit) {
    SchoolStage.values().toList().chunked(2).forEach { pair ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            pair.forEach { stage ->
                FilterChip(
                    selected = selected == stage.name,
                    onClick = { onSelect(stage.name) },
                    label = { Text(stage.displayNameAr, maxLines = 1) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
