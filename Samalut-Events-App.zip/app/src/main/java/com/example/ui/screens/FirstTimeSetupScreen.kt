package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirstTimeSetupScreen(
    initialDirectorate: String = "مديرية التربية والتعليم بالمنيا",
    initialAdministration: String = "إدارة سمالوط التعليمية",
    initialDirectorGeneral: String = "أ/ مدير عام الإدارة",
    initialSecurityOfficer: String = "مستر مصطفى فرغلي",
    onSaveAndContinue: (directorate: String, administration: String, directorGeneral: String, securityOfficer: String) -> Unit
) {
    var directorate by remember { mutableStateOf(initialDirectorate) }
    var administration by remember { mutableStateOf(initialAdministration) }
    var directorGeneral by remember { mutableStateOf(initialDirectorGeneral) }
    var securityOfficer by remember { mutableStateOf(initialSecurityOfficer) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(16.dp))

                // Official Header Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = EduBlueDark),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(EduBlueDark, EduBlue)
                                )
                            )
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(76.dp)
                                .background(EduGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Shield,
                                contentDescription = null,
                                tint = EduBlueDark,
                                modifier = Modifier.size(44.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "الإعداد الأولي للمنظومة",
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "البيانات الإدارية الثابتة والترويسة الرسمية",
                            style = MaterialTheme.typography.bodyMedium,
                            color = EduGold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "يتم استخدام هذه البيانات تلقائياً في ترويسة وتذييل كافة التقارير الرسمية وخطابات خلو الأحداث، مع إمكانية تعديلها لاحقاً من الإعدادات.",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = Color.White.copy(alpha = 0.85f),
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Error Notice
                if (errorMessage != null) {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = errorMessage ?: "",
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(14.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Inputs Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "البيانات الإدارية الأساسية:",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = EduBlue
                        )

                        // 1. Directorate
                        OutlinedTextField(
                            value = directorate,
                            onValueChange = {
                                directorate = it
                                errorMessage = null
                            },
                            label = { Text("اسم المديرية *") },
                            placeholder = { Text("مثال: مديرية التربية والتعليم بالمنيا") },
                            leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_input_directorate"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        // 2. Administration
                        OutlinedTextField(
                            value = administration,
                            onValueChange = {
                                administration = it
                                errorMessage = null
                            },
                            label = { Text("اسم الإدارة التعليمية *") },
                            placeholder = { Text("مثال: إدارة سمالوط التعليمية") },
                            leadingIcon = { Icon(Icons.Default.Domain, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_input_administration"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        // 3. Director General
                        OutlinedTextField(
                            value = directorGeneral,
                            onValueChange = {
                                directorGeneral = it
                                errorMessage = null
                            },
                            label = { Text("اسم مدير عام الإدارة *") },
                            placeholder = { Text("مثال: أ/ مدير عام إدارة سمالوط التعليمية") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = EduBlue) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_input_director_general"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        // 4. Security Officer
                        OutlinedTextField(
                            value = securityOfficer,
                            onValueChange = {
                                securityOfficer = it
                                errorMessage = null
                            },
                            label = { Text("اسم مسؤول أمن الإدارة *") },
                            placeholder = { Text("مثال: مستر مصطفى فرغلي") },
                            leadingIcon = { Icon(Icons.Default.Security, contentDescription = null, tint = EduGreen) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("setup_input_security_officer"),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                // Submit Button
                Button(
                    onClick = {
                        if (directorate.trim().isBlank()) {
                            errorMessage = "يرجى كتابة اسم المديرية التعليمية"
                            return@Button
                        }
                        if (administration.trim().isBlank()) {
                            errorMessage = "يرجى كتابة اسم الإدارة التعليمية"
                            return@Button
                        }
                        if (directorGeneral.trim().isBlank()) {
                            errorMessage = "يرجى كتابة اسم مدير عام الإدارة"
                            return@Button
                        }
                        if (securityOfficer.trim().isBlank()) {
                            errorMessage = "يرجى كتابة اسم مسؤول أمن الإدارة"
                            return@Button
                        }

                        onSaveAndContinue(
                            directorate.trim(),
                            administration.trim(),
                            directorGeneral.trim(),
                            securityOfficer.trim()
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EduGreen),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("setup_save_button")
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "حفظ البيانات وبدء استخدام التطبيق",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
