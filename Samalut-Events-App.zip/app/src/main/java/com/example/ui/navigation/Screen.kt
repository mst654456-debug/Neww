package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object FirstTimeSetup : Screen("first_time_setup")
    object Login : Screen("login")
    object Home : Screen("home")
    object Import : Screen("import")

    object Schools : Screen("schools")
    object SchoolDetail : Screen("school_detail/{schoolId}") {
        fun createRoute(schoolId: Long): String = "school_detail/$schoolId"
    }
    object SchoolForm : Screen("school_form?schoolId={schoolId}") {
        fun createRoute(schoolId: Long? = null): String =
            "school_form?schoolId=${schoolId ?: -1L}"
    }

    object Teachers : Screen("teachers")
    object TeacherForm : Screen("teacher_form?teacherId={teacherId}&schoolId={schoolId}") {
        fun createRoute(teacherId: Long? = null, schoolId: Long? = null): String =
            "teacher_form?teacherId=${teacherId ?: -1L}&schoolId=${schoolId ?: -1L}"
    }

    object Events : Screen("events")
    object EventForm : Screen("event_form?eventId={eventId}&schoolId={schoolId}") {
        fun createRoute(eventId: Long? = null, schoolId: Long? = null): String =
            "event_form?eventId=${eventId ?: -1L}&schoolId=${schoolId ?: -1L}"
    }

    object ReportText : Screen("report_text")
    object Settings : Screen("settings")
}
