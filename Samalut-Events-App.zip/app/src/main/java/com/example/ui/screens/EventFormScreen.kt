package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.SchoolEvent
import com.example.ui.components.AppTopBar
import com.example.ui.components.SchoolPickerDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EventFormScreen(
    existing: SchoolEvent?,
    presetSchoolId: Long?,
    schools: List<School>,
    onSave: (SchoolEvent) -> Unit,
    onBack: () -> Unit
) {
    var schoolId by remember { mutableStateOf(existing?.schoolId ?: presetSchoolId ?: 0L) }
    var title by remember { mutableStateOf(existing?.title.orEmpty()) }
    var description by remember { mutableStateOf(existing?.description.orEmpty()) }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val schoolName = schools.firstOrNull { it.id == schoolId }?.name

    Scaffold(
        topBar = {
            AppTopBar(
                title = if (existing == null) "تسجيل حدث" else "تعديل الحدث",
                onBack = onBack
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text(schoolName?.let { "المدرسة: $it" } ?: "اختر المدرسة *")
            }

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    error = null
                },
                label = { Text("عنوان الحدث *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = description,
                onValueChange = {
                    description = it
                    error = null
                },
                label = { Text("تفاصيل الحدث *") },
                minLines = 6,
                modifier = Modifier.fillMaxWidth()
            )

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = {
                    val school = schools.firstOrNull { it.id == schoolId }
                    if (school == null) {
                        error = "اختر المدرسة أولاً"
                        return@Button
                    }
                    if (title.isBlank()) {
                        error = "اكتب عنوان الحدث"
                        return@Button
                    }
                    if (description.isBlank()) {
                        error = "اكتب تفاصيل الحدث"
                        return@Button
                    }
                    val now = System.currentTimeMillis()
                    val event = existing?.copy(
                        schoolId = school.id,
                        schoolName = school.name,
                        title = title.trim(),
                        description = description.trim()
                    ) ?: SchoolEvent(
                        schoolId = school.id,
                        schoolName = school.name,
                        title = title.trim(),
                        description = description.trim(),
                        dateString = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(now)),
                        timeString = SimpleDateFormat("HH:mm", Locale.US).format(Date(now)),
                        timestamp = now
                    )
                    onSave(event)
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("حفظ الحدث", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showPicker) {
        SchoolPickerDialog(
            schools = schools,
            onPick = { school ->
                schoolId = school.id
                error = null
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}
