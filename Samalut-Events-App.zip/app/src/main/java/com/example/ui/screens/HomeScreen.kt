package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AdminConfig
import com.example.ui.components.AppTopBar
import com.example.ui.theme.EduBlue
import com.example.ui.theme.EduGold

@Composable
fun HomeScreen(
    adminConfig: AdminConfig,
    schoolsCount: Int,
    teachersCount: Int,
    eventsCount: Int,
    onSchools: () -> Unit,
    onTeachers: () -> Unit,
    onEvents: () -> Unit,
    onReport: () -> Unit,
    onImport: () -> Unit,
    onSettings: () -> Unit
) {
    Scaffold(
        topBar = {
            AppTopBar(
                title = "الرئيسية",
                actions = {
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = "الإعدادات")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = EduBlue)
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(18.dp)) {
                    Text(
                        text = "إدارة الأحداث",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = adminConfig.administrationName,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )
                    Text(
                        text = "المسؤول: ${adminConfig.securityOfficerName}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = EduGold
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                HomeTile(
                    title = "المدارس",
                    subtitle = "$schoolsCount مدرسة",
                    icon = Icons.Filled.School,
                    modifier = Modifier.weight(1f).height(130.dp),
                    onClick = onSchools
                )
                HomeTile(
                    title = "المعلمون",
                    subtitle = "$teachersCount معلم",
                    icon = Icons.Filled.Person,
                    modifier = Modifier.weight(1f).height(130.dp),
                    onClick = onTeachers
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                HomeTile(
                    title = "الأحداث",
                    subtitle = "$eventsCount حدث",
                    icon = Icons.Filled.Warning,
                    modifier = Modifier.weight(1f).height(130.dp),
                    onClick = onEvents
                )
                HomeTile(
                    title = "إرسال PDF",
                    subtitle = "كتابة وإرسال تقرير",
                    icon = Icons.Filled.PictureAsPdf,
                    modifier = Modifier.weight(1f).height(130.dp),
                    onClick = onReport
                )
            }

            HomeTile(
                title = "استيراد من Excel",
                subtitle = "إضافة المدارس والمعلمين من ملف",
                icon = Icons.Filled.Description,
                modifier = Modifier.fillMaxWidth().height(96.dp),
                onClick = onImport
            )
        }
    }
}

@Composable
private fun HomeTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Card(onClick = onClick, modifier = modifier, shape = RoundedCornerShape(18.dp)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = EduBlue, modifier = Modifier.size(34.dp))
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
        }
    }
}
