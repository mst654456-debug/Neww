package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.SchoolEvent
import com.example.ui.components.AppTopBar
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyState

@Composable
fun EventsScreen(
    events: List<SchoolEvent>,
    onAdd: () -> Unit,
    onOpen: (SchoolEvent) -> Unit,
    onDelete: (SchoolEvent) -> Unit,
    onTransfer: (List<SchoolEvent>) -> Unit,
    onPrint: (todayOnly: Boolean) -> Unit,
    onBack: () -> Unit
) {
    var selected by remember { mutableStateOf(setOf<Long>()) }
    var showPrintChoice by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<SchoolEvent?>(null) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "الأحداث (${events.size})",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { showPrintChoice = true }) {
                        Icon(Icons.Filled.Print, contentDescription = "ترحيل للتقرير")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("تسجيل حدث") }
            )
        },
        bottomBar = {
            if (selected.isNotEmpty()) {
                Button(
                    onClick = {
                        onTransfer(events.filter { it.id in selected })
                        selected = emptySet()
                    },
                    modifier = Modifier.fillMaxWidth().padding(16.dp).height(52.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Text("ترحيل المحدد للتقرير (${selected.size})", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { padding ->
        if (events.isEmpty()) {
            Column(modifier = Modifier.padding(padding).fillMaxSize()) {
                EmptyState("لا توجد أحداث مسجلة بعد.\nاضغط «تسجيل حدث» للبدء.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(events, key = { it.id }) { event ->
                    EventCard(
                        event = event,
                        checked = event.id in selected,
                        onCheckedChange = { checked ->
                            selected = if (checked) selected + event.id else selected - event.id
                        },
                        onClick = { onOpen(event) },
                        onDelete = { deleteTarget = event }
                    )
                }
            }
        }
    }

    if (showPrintChoice) {
        AlertDialog(
            onDismissRequest = { showPrintChoice = false },
            title = { Text("ترحيل الأحداث للتقرير", fontWeight = FontWeight.Bold) },
            text = {
                Text("اختر الأحداث اللي هتتنقل لصفحة التقرير. تقدر تختار أحداث معينة بالعلامة ✓ من القائمة وتبعتها من الزرار اللي تحت.")
            },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        showPrintChoice = false
                        onPrint(true)
                    }) { Text("أحداث اليوم") }
                    TextButton(onClick = {
                        showPrintChoice = false
                        onPrint(false)
                    }) { Text("كل الأحداث") }
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrintChoice = false }) { Text("إلغاء") }
            }
        )
    }

    deleteTarget?.let { target ->
        ConfirmDialog(
            title = "حذف الحدث",
            message = "هل تريد حذف الحدث «${target.title}»؟",
            confirmText = "حذف",
            onConfirm = {
                onDelete(target)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun EventCard(
    event: SchoolEvent,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 4.dp, end = 4.dp, top = 8.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(checked = checked, onCheckedChange = onCheckedChange)
            Column(modifier = Modifier.weight(1f).padding(horizontal = 4.dp)) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text("المدرسة: ${event.schoolName}", style = MaterialTheme.typography.bodySmall)
                Text(
                    "${event.dateString}  •  ${event.timeString}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = event.description,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
