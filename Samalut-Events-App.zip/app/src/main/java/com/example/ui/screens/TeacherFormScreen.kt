package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.Teacher
import com.example.data.model.TeacherSpec
import com.example.data.model.toValues
import com.example.ui.components.AppTopBar
import com.example.ui.components.FormFields
import com.example.ui.components.SchoolPickerDialog

@Composable
fun TeacherFormScreen(
    existing: Teacher?,
    presetSchoolId: Long?,
    schools: List<School>,
    onSave: (Long, Long, Map<String, String>) -> Unit,
    onBack: () -> Unit
) {
    val values = remember {
        mutableStateMapOf<String, String>().apply { putAll(existing?.toValues().orEmpty()) }
    }
    var schoolId by remember { mutableStateOf(existing?.schoolId ?: presetSchoolId ?: 0L) }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val schoolName = schools.firstOrNull { it.id == schoolId }?.name

    Scaffold(
        topBar = {
            AppTopBar(
                title = if (existing == null) "إضافة معلم" else "تعديل بيانات المعلم",
                onBack = onBack
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text(schoolName?.let { "المدرسة: $it" } ?: "اختر المدرسة *")
            }

            FormFields(TeacherSpec.fields, values)

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = {
                    if (schoolId == 0L) {
                        error = "اختر المدرسة التابع لها المعلم"
                        return@Button
                    }
                    if (values["name"].isNullOrBlank()) {
                        error = "اكتب اسم المعلم أولاً"
                        return@Button
                    }
                    onSave(existing?.id ?: 0L, schoolId, values.toMap())
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("حفظ بيانات المعلم", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showPicker) {
        SchoolPickerDialog(
            schools = schools,
            onPick = { school ->
                schoolId = school.id
                error = null
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}
