package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.stageLabel
import com.example.ui.components.AppTopBar
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyState
import com.example.ui.components.PhoneActions
import com.example.ui.components.SearchField
import com.example.ui.theme.EduBlue

@Composable
fun SchoolsScreen(
    schools: List<School>,
    onAdd: () -> Unit,
    onOpen: (School) -> Unit,
    onDelete: (School) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<School?>(null) }
    val q = query.trim()
    val filtered = schools.filter {
        it.name.contains(q, ignoreCase = true) || it.code.contains(q, ignoreCase = true)
    }

    Scaffold(
        topBar = { AppTopBar(title = "المدارس (${schools.size})", onBack = onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAdd,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("إضافة مدرسة") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            SearchField(value = query, onValueChange = { query = it }, placeholder = "بحث بالاسم أو الكود")
            Spacer(modifier = Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                EmptyState(
                    if (schools.isEmpty()) "لا توجد مدارس مسجلة بعد.\nاضغط «إضافة مدرسة» أو استورد من Excel."
                    else "لا توجد نتائج للبحث."
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(filtered, key = { it.id }) { school ->
                        SchoolCard(
                            school = school,
                            onClick = { onOpen(school) },
                            onDelete = { deleteTarget = school }
                        )
                    }
                }
            }
        }
    }

    deleteTarget?.let { target ->
        ConfirmDialog(
            title = "حذف المدرسة",
            message = "هيتم حذف مدرسة «${target.name}» ومعلميها. الأحداث المسجلة هتفضل في التقارير.",
            confirmText = "حذف",
            onConfirm = {
                onDelete(target)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun SchoolCard(school: School, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.School, contentDescription = null, tint = EduBlue, modifier = Modifier.size(36.dp))
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(school.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("المرحلة: ${stageLabel(school.stage)}", style = MaterialTheme.typography.bodySmall)
                if (school.principalName.isNotBlank()) {
                    Text("المدير: ${school.principalName}", style = MaterialTheme.typography.bodySmall)
                }
            }
            PhoneActions(school.principalPhone)
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}
